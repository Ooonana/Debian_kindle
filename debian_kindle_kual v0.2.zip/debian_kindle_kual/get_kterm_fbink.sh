#!/bin/sh
sleep 1
sh get_kterm.sh | fbink -I -y 40
