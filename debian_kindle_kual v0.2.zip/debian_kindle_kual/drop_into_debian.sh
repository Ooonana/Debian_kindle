#!/bin/sh

if [ -f /mnt/us/debian.sh ] && [ -f /etc/upstart/debian.conf ] && [ -f /mnt/us/debian.ext3 ] ; then
	/mnt/us/extensions/kterm/bin/kterm -e "sh /mnt/us/debian.sh" -k 1 -o U -s 7
else
	fbink -pmh -y -5 "Error: Required files missing. Deploy Debian first!"
fi
