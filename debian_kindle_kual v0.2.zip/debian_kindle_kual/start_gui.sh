#!/bin/sh

if [ -f /mnt/us/debian.sh ] && [ -f /etc/upstart/debian.conf ] && [ -f /mnt/us/debian.ext3 ] ; then
	start alpine
else
	fbink -pmh -y -5 "Error: Required files missing. Check the Debian files first!"
fi
