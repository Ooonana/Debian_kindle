#!/bin/sh

/mnt/us/extensions/kterm/bin/kterm -e "bash /mnt/us/extensions/debian_kindle_kual/deploy.sh" -k 1 -o U -s 7
