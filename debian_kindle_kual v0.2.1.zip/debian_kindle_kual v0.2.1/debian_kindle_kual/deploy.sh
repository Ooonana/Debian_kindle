#!/bin/sh

# Define source and destination
SRC="/mnt/us/debian.conf"
DEST="/etc/upstart/debian.conf"

# Check if source file exists
if [ -f "$SRC" ]; then
    mntroot ro
    cp "$SRC" "$DEST"
    echo "File copied successfully."
else
    echo "Source file does not exist: $SRC"
    mntroot ro
    exit 1
fi